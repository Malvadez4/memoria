MINHA TRAJETÓRIA ESCOLAR

Arquivos: index.html, style.css e script.js.
Coloque suas imagens na pasta assets com os nomes img1.jpeg até img12.jpeg, ou altere os caminhos no HTML.
Abra index.html no navegador para testar. Para publicar no GitHub Pages, envie a pasta e habilite Pages nas configurações do repositório.

As redações estão organizadas em 15 cards. Confira os textos e complete qualquer redação cujo conteúdo esteja marcado como espaço para colar.
